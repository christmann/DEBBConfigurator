<?php

namespace Debb\ConfigBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Class DebbConfigBundle
 * @package Debb\ConfigBundle
 */
class DebbConfigBundle extends Bundle
{
}
