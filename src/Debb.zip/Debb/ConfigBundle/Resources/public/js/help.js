$(function()
{
    $('.accordion').accordion({
        header: 'h3',
        collapsible: true
    });
});