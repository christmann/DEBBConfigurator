<?php

namespace Debb\ManagementBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Class DebbManagementBundle
 * @package Debb\ManagementBundle
 */
class DebbManagementBundle extends Bundle
{
}
